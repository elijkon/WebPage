public class Savings extends Account {
    //constructors
    public Savings() {
        super();
    }

    public Savings(String nm, int TxId, double balnce) {
        super(nm, TxId, balnce);
    }

    //methods
    public void DoWithdraw(double amount) {
        if (amount <= Balance) {        //makes there is enough money in account
            Balance = Balance - amount; //subtracting given amount from balance
            int i = NumWithdraws % Last10Withdraws.length; //using mod to get index.
            Last10Withdraws[i] = amount;
            NumWithdraws++;  //adding withdrawal amount to array and increasing number of withdrawals.
            System.out.println("You have withdrawaled $" + amount + ". Your Balance is now $" + Balance + ".");
        } else {
            System.out.println("Insufficient funds. Your Balance currently is $" + Balance + ".");
        }
    }

    public void display() {
        super.display();        // calls display in constructor
        System.out.println("\nSavings Account Summary\n");

        // Print deposits
        System.out.println("Deposits:");
        for (int i = 0; i < Last10Deposits.length; i++) {       //shows the last 10 deposits with amount.
            System.out.println("Deposit " + (i + 1) + ": Amount = " + Last10Deposits[i]);
        }

        // Print withdraws
        System.out.println("\nWithdraws:");
        for (int i = 0; i < Last10Withdraws.length; i++) {      // //shows the last 10 withdrawals with amount.
            System.out.println("Withdraw " + (i + 1) + ": Amount = " + Last10Withdraws[i]);
        }
    }
}
