import java.util.InputMismatchException;
import java.util.Locale;
import java.util.Scanner;
import java.util.Random;

public class RunBank {
    public static void main(String args[]) {
        //constructors and scanners
        Scanner scan = new Scanner(System.in);
        Random gen = new Random();

        int tx = gen.nextInt(1000000);
        Checking Ch = new Checking("checking", tx, 100);
        Savings Sa = new Savings("saving", tx, 100);
        CreditCard Cc = new CreditCard("CreditCard", tx, 100);

        //variables
        String r; // String response variable for scanner
        int m; //int response for menu

        //setting name
        System.out.println("------------------------------------------\nHello welcome to Umbrella Corp Financials.\n" +
                "Please enter your first name.");
        r = scan.nextLine();
        Ch.setName(r);
        Sa.setName(r);
        Cc.setName(r);
        System.out.println("\nHello " + r + "," + "\n" + "please choose a option from the menu by entering the number. \n");
        for (int i = 0; i < 100000; i++) {      //loop that prints out the menu after doing one task
            System.out.println("************************\nUmbrella Corp Financials\n" +
                    "************************");
            System.out.println(
                    "\n1. Savings Deposit\n" +
                            "2. Savings Withdrawal\n" +
                            "3. Checking Deposit\n" +
                            "4. Write A Check\n" +
                            "5. Credit Card Payment\n" +
                            "6. Make A Charge\n"
                            + "7. Display Savings  | " + "Balance: " + Sa.Balance + "\n"
                            + "8. Display Checking | " + "Balance: " + Ch.Balance + "$" + "\n"
                            + "9. Display Credit Card | " + "Balance: " + Cc.Balance + "$" + "\n"
                            + "10. Exit\n" +
                            "Enter menu selection : "
            );
            double ans; //answer variable
            while (true) {
                try {           //tries to get answer
                    m = scan.nextInt(); //
                    scan.nextLine();
                    break;
                } catch (InputMismatchException e) {        //catches if wrong data type
                    System.out.println("Invalid input.");
                    scan.nextLine();
                }
            }
            switch (m) {
                case 1:
                    System.out.print("How much would you like to deposit into your savings?\n$");
                    try {                   //tries to get answer
                        ans = scan.nextDouble();
                        scan.nextLine();
                    } catch (InputMismatchException e) {                //catches if wrong data type
                        System.out.println("Invalid input.");
                        scan.nextLine();
                        ans = 0;
                    }
                    Sa.MakeDeposit(ans);
                    break;

                case 2:
                    System.out.print("How much would you like to withdrawal from your Savings? \n$");
                    try {           //tries to get answer
                        ans = scan.nextDouble();
                        scan.nextLine();
                    } catch (InputMismatchException e) {    //catches if wrong data type
                        System.out.println("Invalid input.");
                        scan.nextLine();
                        ans = 0;
                    }
                    Sa.DoWithdraw(ans);
                    break;

                case 3:
                    System.out.print("How much would you like to deposit into your Checking account?\n$");
                    try {       //tries to get answer
                        ans = scan.nextDouble();
                        scan.nextLine();
                    } catch (InputMismatchException e) {    //catches if wrong data type
                        System.out.println("Invalid input.");
                        scan.nextLine();
                        ans = 0;
                    }
                    Ch.MakeDeposit(ans);
                    System.out.println("Your Balance is: $" + Ch.Balance + ".");
                    break;

                case 4:

                    System.out.print("Please type in your check number.\n");
                    try {       //tries to get answer
                        m = scan.nextInt();
                        scan.nextLine();
                    } catch (InputMismatchException e) {        //catches if wrong data type
                        System.out.println("Invalid input assigning a random check number.");
                        scan.nextLine();
                        m = gen.nextInt(1000000);
                    }
                    System.out.print("What is the amount that you would like to add to check #" + m + "\n$");
                    try {       //tries to get answer
                        ans = scan.nextDouble();
                        scan.nextLine();
                    } catch (InputMismatchException e) {        //catches if wrong data type
                        System.out.println("Invalid input setting check to zero.");
                        scan.nextLine();
                        ans = 0;
                    }
                    Ch.WriteCheck(m, ans);
                    break;

                case 5:
                    System.out.print("Please enter the amount you would like to pay to your credit balance.\n$");
                    try {       //catches if wrong data type
                        ans = scan.nextDouble();
                        scan.nextLine(); //clears rest of line
                    } catch (InputMismatchException e) {
                        System.out.println("Invalid input.");
                        scan.nextLine();
                        ans = 0;
                    }
                    Cc.MakePayment(ans);
                    break;

                case 6:
                    String nm;
                    System.out.println("Please enter the name of the charge?");
                    try {           //tries to get answer
                        nm = scan.nextLine();
                    } catch (InputMismatchException e) {        //catches if wrong data type
                        System.out.println("Invalid input.");
                        scan.nextLine();
                        nm = "Unknown charge";
                    }
                    System.out.print("Please enter how much the charge is.\n$");
                    try {           //tries to get answer
                        ans = scan.nextDouble();
                        scan.nextLine();
                    } catch (InputMismatchException e) {        //catches if wrong data type
                        System.out.println("Invalid input.");
                        scan.nextLine();
                        ans = 0;
                    }
                    Cc.DebtCharge(nm, ans);
                    break;

                case 7: //display savings
                    Sa.display();
                    break;

                case 8: //display checking
                    Ch.display();
                    break;

                case 9: //display credit card
                    Cc.display();
                    break;

                case 10:
                    System.out.println("Ending program.");
                    return;
                default:
                    System.out.println("Invalid input");

            } //asks user after doing one task if they would like to return to menu or exit program.
            boolean answer = false;
            while (answer == false) {
                System.out.println("Type done to continue back to menu or exit to end program.");
                r = scan.nextLine().toLowerCase(Locale.ROOT);
                if (r.contains("done")) {
                    System.out.println("Going back to menu...");
                    answer = true;
                } else if (r.contains("exit")) {
                    System.out.println("Ending Program.");
                    return;

                } else {
                    System.out.println("Invalid input");
                }
            }

        }

    }
}