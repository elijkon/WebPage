/*
Name: Elijah Konkle
Date: 9/26/2024
Class: 1120 Section 1
Honor Pledge: I have neither given nor received unauthorized aid on this program.
Description: This is a program that acts as a bank account. The Account class allows for
             updates and modification to the child classes. Each class represents its own account.
Input: First the user will need to enter a number for the menu. The user will then input numbers or strings based on the task that they are doing.
Output: The output will be the updated balance usually or what the task just did.
 */

//Parent
public class Account {
    //Variables

    protected String Name;
    protected int TaxId = 0;
    protected double Balance = 0;
    protected double[] Last10Withdraws = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
    protected double[] Last10Deposits = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
    protected int NumDeposits = 0;
    protected int NumWithdraws = 0;

    //Constructors

    public Account() {

    }

    public Account(String nm, int TxId, double balnce) {
        this.Name = nm;
        this.TaxId = TxId;
        this.Balance = balnce;
    }

    //mutators
    protected void setName(String nm) {
        if (nm == null) { //makes sure name is not null
            System.out.println("Name is null, please enter valid name.");
        } else {
            this.Name = nm;
        }
    }

    protected void setTaxId(int ta) {
        if (ta <= 999999999 && ta >= 100000000) {       //makes sure tax id is 9 lengths long
            this.TaxId = ta;
        }
        System.out.println("Your tax ID must be 9 numbers.");
    }

    protected void setBalance(double ba) {
        if (ba > 0.0) {                 //makes sure balance is above 0
            this.Balance = ba;
        }
    }

    protected void MakeDeposit(double amnt) {
        if (amnt <= 0.0) {      //makes sure amount is greater than 0
            System.out.println("Please deposit more than 0 dollars without the dollar symbol.");

        } else {
            this.Balance += amnt; //adds amount to balance
            int index = NumDeposits % Last10Deposits.length;       //uses mod to get index
            Last10Deposits[index] = amnt;       //adds amount to index
            NumDeposits++;  //increases count
            System.out.println("You have deposited $" + amnt + ".");
        }
    }

    //Accessors

    protected String getName() {
        return this.Name;
    }

    protected int getTaxId() {
        return this.TaxId;
    }

    protected double getBalance() {
        return this.Balance;
    }

    public void display() {
        System.out.println("Name: " + this.Name);
        System.out.println("Tax ID: " + this.TaxId);
        System.out.println("Balance: $" + this.Balance);
    }

}
