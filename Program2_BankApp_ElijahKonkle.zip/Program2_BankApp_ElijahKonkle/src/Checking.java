public class Checking extends Account {
    //constructors

    public Checking() {
        super();
    }

    public Checking(String nm, int TxId, double balnce) {
        super(nm, TxId, balnce);
    }

    //variables

    private int[] Last10Checks = new int[10];

    //methods

    public void WriteCheck(int checknum, double amount) {
        int index = NumWithdraws % Last10Checks.length; //gets index using mod
        if (amount <= Balance) {        //makes sure there is enough money
            Balance = Balance - amount;     //adjusts amount
            Last10Checks[index] = checknum;     //adds check number to array
            index = NumWithdraws % Last10Withdraws.length;  //uses mod to get index
            Last10Withdraws[index] = amount;    //adds amount to withdrawals
            NumWithdraws++;     //adds count
            System.out.println("You have written a check for $" + amount + ". Check number: " + checknum);
        } else {
            System.out.println("Insufficient funds. Balance: $" + Balance + ".");
        }
    }

    public void display() {
        super.display();        // calls display in constructor
        System.out.println("\nChecking Account Summary\n");

        // Print the last 10 checks with number and amount
        System.out.println("Check Register:");
        for (int i = 0; i < Last10Checks.length; i++) {
            System.out.println("Check number: " + Last10Checks[i] + ", Amount: " + Last10Withdraws[i]);
        }

        // Print deposit records with amount
        System.out.println("\nDeposits:");
        for (int i = 0; i < Last10Deposits.length; i++) {
            System.out.println("Deposit " + (i + 1) + ": Amount = " + Last10Deposits[i]);
        }


    }
}
