public class CreditCard extends Account {
    //constructors
    public CreditCard() {
        super();
    }

    public CreditCard(String nm, int TxId, double balnce) {
        super(nm, TxId, balnce);
    }

    //variables

    private int CardNumber = 574545892;
    private String[] Last10Charges = new String[10];
    private int NumCharges = 0;

    //methods

    public void DebtCharge(String name, double amount) {
        final int limit = 5000;
        if ((Balance + amount) <= limit) {  //makes sure they do not reach there limit
            Balance = Balance + amount;         //increases balance
            int index = NumCharges % Last10Charges.length;      //mods to get index
            Last10Charges[index] = name;   //adds name to last charges
            index = NumWithdraws % Last10Withdraws.length;
            Last10Withdraws[index] = amount;    //adds amount to withdraws
            NumWithdraws++;     //increases both counts
            NumCharges++;
            System.out.println("You made a charge too " + name + " with an amount of " + amount + "$.");
        } else {
            System.out.println("You cannot go over limit 5000. Your current balance is: " + Balance + "$.");
        }
    }

    public void MakePayment(double amount) {
        if (amount <= 0.0) {    //makes sure payment is more than 0
            System.out.println("Please enter positive amount.");
        } else {
            Balance = Balance - amount;     //adjusts balance
            int index = NumDeposits % Last10Deposits.length;    //uses mod to get index
            Last10Deposits[index] = amount;     //adds to deposits
            NumDeposits++;  //increases count
            System.out.println("You have made a payment of $" + amount + ". Your balance is now $" + Balance);
        }
    }

    public void display() {
        super.display();        // calls display in constructor
        System.out.println("\nCredit Card Account Summary\nCard Number: " + CardNumber);

        // Print the last 10 checks
        System.out.println("Account charges:");
        for (int i = 0; i < Last10Withdraws.length; i++) {  //shows last charges with name and amount
            if (Last10Charges[i] == null) {
                System.out.println("Charge name: N/A, Amount: " + Last10Withdraws[i]);
            } else {
                System.out.println("Charge name: " + Last10Charges[i] + ", Amount: " + Last10Withdraws[i]);
            }
        }

        // Print deposit records
        System.out.println("\nDeposits:");
        for (int i = 0; i < Last10Deposits.length; i++) {       //shows the last 10 deposits with amount.
            System.out.println("Deposit " + (i + 1) + ": Amount = " + Last10Deposits[i]);
        }
    }

}
